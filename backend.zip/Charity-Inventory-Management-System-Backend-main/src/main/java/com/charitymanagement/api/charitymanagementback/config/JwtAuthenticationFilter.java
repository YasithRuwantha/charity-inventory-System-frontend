package com.charitymanagement.api.charitymanagementback.config;

import com.charitymanagement.api.charitymanagementback.auth.service.JwtService;
import com.charitymanagement.api.charitymanagementback.common.security.JwtErrorAttributes;
import io.jsonwebtoken.ExpiredJwtException;
import io.jsonwebtoken.JwtException;
import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import lombok.RequiredArgsConstructor;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.lang.NonNull;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.web.authentication.WebAuthenticationDetailsSource;
import org.springframework.stereotype.Component;
import org.springframework.web.filter.OncePerRequestFilter;

import java.io.IOException;

@Component
@RequiredArgsConstructor
public class JwtAuthenticationFilter extends OncePerRequestFilter {

    private static final Logger log = LoggerFactory.getLogger(JwtAuthenticationFilter.class);

    private final JwtService jwtService;
    private final UserDetailsService userDetailsService;

    @Override
    protected void doFilterInternal(
            @NonNull HttpServletRequest request,
            @NonNull HttpServletResponse response,
            @NonNull FilterChain filterChain
    ) throws ServletException, IOException {
        final String authHeader = request.getHeader("Authorization");
        final String jwt;
        final String userEmail;

        if (authHeader == null || !authHeader.startsWith("Bearer ")) {
            filterChain.doFilter(request, response);
            return;
        }

        jwt = authHeader.substring(7);

        try {
            userEmail = jwtService.extractUsername(jwt);

            if (userEmail != null && SecurityContextHolder.getContext().getAuthentication() == null) {
                UserDetails userDetails = this.userDetailsService.loadUserByUsername(userEmail);
                if (jwtService.isTokenValid(jwt, userDetails) && userDetails.isEnabled()) {
                    UsernamePasswordAuthenticationToken authToken = new UsernamePasswordAuthenticationToken(
                            userDetails,
                            null,
                            userDetails.getAuthorities()
                    );
                    authToken.setDetails(new WebAuthenticationDetailsSource().buildDetails(request));
                    SecurityContextHolder.getContext().setAuthentication(authToken);
                } else if (!userDetails.isEnabled()) {
                    request.setAttribute(JwtErrorAttributes.JWT_ERROR_ATTRIBUTE, "This account is deactivated");
                }
            }
        } catch (ExpiredJwtException ex) {
            // Leave the context unauthenticated; the entry point turns this into a 401 JSON body.
            request.setAttribute(JwtErrorAttributes.JWT_ERROR_ATTRIBUTE, "The access token has expired");
        } catch (JwtException | IllegalArgumentException ex) {
            request.setAttribute(JwtErrorAttributes.JWT_ERROR_ATTRIBUTE, "The access token is invalid");
            log.debug("Rejected a malformed bearer token: {}", ex.getMessage());
        } catch (UsernameNotFoundException ex) {
            request.setAttribute(JwtErrorAttributes.JWT_ERROR_ATTRIBUTE,
                    "The account referenced by this token no longer exists");
        }

        filterChain.doFilter(request, response);
    }
}
